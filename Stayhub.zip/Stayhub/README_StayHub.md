# 🏨 StayHub – Hotel Management System

## Smart Hotel Operations Powered by Spring Boot & MongoDB

**Developed By:** Kaushal Tanna  
**Registration No:** 24BCE10364

---

## 📖 Overview

StayHub is a Hotel Management System developed using Java Spring Boot and MongoDB. It provides a centralized platform for managing guests, rooms, bookings, payments, staff, departments, and amenities through RESTful APIs.

---

## ✨ Features

### 👤 Guest Management
- Add, update, view and delete guest records

### 🛏️ Room Management
- Manage rooms and availability

### 📅 Booking Management
- Create and manage reservations

### 💳 Payment Management
- Record and track payments

### 👨‍💼 Staff Management
- Manage hotel employees

### 🏢 Department Management
- Organize departments and staff

### ⭐ Amenities Management
- Manage hotel amenities and facilities

---

## 🛠️ Technology Stack

- Java
- Spring Boot
- MongoDB
- Maven
- Swagger UI
- Postman

---

## 📂 Project Structure

StayHub
- Controllers
- Services
- Repositories
- Models
- Configurations
- Resources
- StayhubApplication.java

---

## 🚀 How to Run

### Prerequisites

- Java 17+
- MongoDB
- Maven
- Eclipse / IntelliJ IDEA
- Postman

### Steps

1. Start MongoDB.
2. Open the project in Eclipse or IntelliJ IDEA.
3. Allow Maven dependencies to download.
4. Open StayhubApplication.java.
5. Run as Java Application.
6. Verify application starts successfully.
7. Access Swagger UI.

---

## 📚 Swagger Documentation

http://localhost:8080/swagger-ui/index.html

---

## 🔄 Available Modules

- Guests
- Rooms
- Bookings
- Payments
- Staff
- Departments
- Amenities

All modules support CRUD operations.

---

## 🎯 Objectives

- Simplify hotel operations
- Improve booking management
- Centralize hotel data
- Demonstrate Spring Boot and MongoDB integration

---

## 🔮 Future Enhancements

- Online Payments
- Authentication & Authorization
- Email Notifications
- Analytics Dashboard
- Mobile App Integration

---

## 👨‍💻 Author

Kaushal Tanna  
B.Tech CSE, VIT Bhopal University

---

### StayHub – Making Hotel Management Smarter & Simpler
