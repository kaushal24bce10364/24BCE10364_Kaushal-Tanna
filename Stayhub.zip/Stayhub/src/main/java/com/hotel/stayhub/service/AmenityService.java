package com.hotel.stayhub.service;

import com.hotel.stayhub.model.Amenity;
import com.hotel.stayhub.repository.AmenityRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class AmenityService {

    @Autowired
    private AmenityRepository amenityRepository;

    // Create or Update an Amenity
    public Amenity saveAmenity(Amenity amenity) {
        return amenityRepository.save(amenity);
    }

    // Get all Amenities
    public List<Amenity> getAllAmenities() {
        return amenityRepository.findAll();
    }

    // Get a single Amenity by ID
    public Optional<Amenity> getAmenityById(String id) {
        return amenityRepository.findById(id);
    }

    // Delete an Amenity by ID
    public void deleteAmenity(String id) {
        amenityRepository.deleteById(id);
    }
}