package com.hotel.stayhub.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
import java.util.Date;

@Document(collection = "payments")
public class Payment {

    @Id
    private String id;
    private double amount;
    private String paymentMethod;
    private String status;
    private Date transactionDate;

    // Links this standalone payment record back to its parent Booking.
    // Kept in sync with the embedded copy stored inside Booking.payment.
    private String bookingId;

    // Default Constructor
    public Payment() {
    }

    // Parameterized Constructor
    public Payment(double amount, String paymentMethod, String status, Date transactionDate) {
        this.amount = amount;
        this.paymentMethod = paymentMethod;
        this.status = status;
        this.transactionDate = transactionDate;
    }

    // Getters and Setters - These MUST match the Controller calls
    public String getId() { return id; }
    public void setId(String id) { this.id = id; }

    public double getAmount() { return amount; }
    public void setAmount(double amount) { this.amount = amount; }

    public String getPaymentMethod() { return paymentMethod; }
    public void setPaymentMethod(String paymentMethod) { this.paymentMethod = paymentMethod; }

    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }

    public Date getTransactionDate() { return transactionDate; }
    public void setTransactionDate(Date transactionDate) { this.transactionDate = transactionDate; }

    public String getBookingId() { return bookingId; }
    public void setBookingId(String bookingId) { this.bookingId = bookingId; }
}