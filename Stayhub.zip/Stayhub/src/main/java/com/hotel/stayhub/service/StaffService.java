package com.hotel.stayhub.service;

import com.hotel.stayhub.model.Staff;
import com.hotel.stayhub.repository.StaffRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class StaffService {

    @Autowired
    private StaffRepository staffRepository;

    // Create or Update Staff
    public Staff saveStaff(Staff staff) {
        return staffRepository.save(staff);
    }

    // Get all Staff
    public List<Staff> getAllStaff() {
        return staffRepository.findAll();
    }

    // Get single Staff by ID
    public Optional<Staff> getStaffById(String id) {
        return staffRepository.findById(id);
    }

    // Get all Staff belonging to a specific Department (One-to-Many lookup)
    public List<Staff> getStaffByDepartmentId(String departmentId) {
        return staffRepository.findByDepartment_Id(departmentId);
    }

    // Delete Staff by ID
    public void deleteStaff(String id) {
        staffRepository.deleteById(id);
    }
}