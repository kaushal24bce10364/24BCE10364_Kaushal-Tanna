package com.hotel.stayhub.repository;

import com.hotel.stayhub.model.Department;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface DepartmentRepository extends MongoRepository<Department, String> {
    // This interface automatically inherits full CRUD operations for the departments collection
}