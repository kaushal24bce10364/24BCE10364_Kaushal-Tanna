package com.hotel.stayhub.controller;

import com.hotel.stayhub.model.Amenity;
import com.hotel.stayhub.service.AmenityService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/amenities")
public class AmenityController {

    @Autowired
    private AmenityService amenityService;

    // Create a new Amenity
    @PostMapping
    public ResponseEntity<Amenity> createAmenity(@RequestBody Amenity amenity) {
        Amenity savedAmenity = amenityService.saveAmenity(amenity);
        return new ResponseEntity<>(savedAmenity, HttpStatus.CREATED);
    }

    // Get all Amenities
    @GetMapping
    public ResponseEntity<List<Amenity>> getAllAmenities() {
        List<Amenity> amenities = amenityService.getAllAmenities();
        return new ResponseEntity<>(amenities, HttpStatus.OK);
    }

    // Get a single Amenity by ID
    @GetMapping("/{id}")
    public ResponseEntity<Amenity> getAmenityById(@PathVariable String id) {
        Optional<Amenity> amenity = amenityService.getAmenityById(id);
        return amenity.map(value -> new ResponseEntity<>(value, HttpStatus.OK))
                .orElseGet(() -> new ResponseEntity<>(HttpStatus.NOT_FOUND));
    }

    // Update an Amenity by ID
    @PutMapping("/{id}")
    public ResponseEntity<Amenity> updateAmenity(@PathVariable String id, @RequestBody Amenity amenityDetails) {
        Optional<Amenity> optionalAmenity = amenityService.getAmenityById(id);

        if (optionalAmenity.isPresent()) {
            Amenity existingAmenity = optionalAmenity.get();
            existingAmenity.setName(amenityDetails.getName());
            existingAmenity.setDescription(amenityDetails.getDescription());
            
            Amenity updatedAmenity = amenityService.saveAmenity(existingAmenity);
            return new ResponseEntity<>(updatedAmenity, HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    // Delete an Amenity by ID
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteAmenity(@PathVariable String id) {
        Optional<Amenity> amenity = amenityService.getAmenityById(id);
        if (amenity.isPresent()) {
            amenityService.deleteAmenity(id);
            return new ResponseEntity<>(HttpStatus.NO_CONTENT);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }
}