package com.hotel.stayhub.repository;

import com.hotel.stayhub.model.Payment;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface PaymentRepository extends MongoRepository<Payment, String> {
    // This interface automatically inherits full CRUD operations for the payments collection

    // Custom query to look up the payment record linked to a specific booking
    java.util.Optional<Payment> findByBookingId(String bookingId);
}