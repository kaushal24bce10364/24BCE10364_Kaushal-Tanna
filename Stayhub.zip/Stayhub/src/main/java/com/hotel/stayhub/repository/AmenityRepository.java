package com.hotel.stayhub.repository;

import com.hotel.stayhub.model.Amenity;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface AmenityRepository extends MongoRepository<Amenity, String> {
    // This interface automatically inherits full CRUD operations for the amenities collection
}