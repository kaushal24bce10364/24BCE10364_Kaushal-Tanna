package com.hotel.stayhub.repository;

import com.hotel.stayhub.model.Guest;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface GuestRepository extends MongoRepository<Guest, String> {
    // This interface automatically inherits full CRUD operations for the guests collection
    // You can add custom query methods here later, such as findByEmail(String email)
}