package com.hotel.stayhub.controller;

import com.hotel.stayhub.model.Amenity;
import com.hotel.stayhub.model.Room;
import com.hotel.stayhub.service.AmenityService;
import com.hotel.stayhub.service.RoomService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/rooms")
public class RoomController {

    @Autowired
    private RoomService roomService;

    @Autowired
    private AmenityService amenityService;

    // Create a new Room entry
    @PostMapping
    public ResponseEntity<Room> createRoom(@RequestBody Room room) {
        System.out.println("\n>>> [CONSOLE LOG] Incoming POST request to create a new room...");
        System.out.println(">>> Attempting to save Room #" + room.getRoomNumber() + " (" + room.getType() + ") - Price: $" + room.getPrice());
        
        Room savedRoom = roomService.saveRoom(room);
        
        System.out.println(">>> [CONSOLE LOG] SUCCESS: Room saved with MongoDB ID: " + savedRoom.getId());
        return new ResponseEntity<>(savedRoom, HttpStatus.CREATED);
    }

    // Get all Rooms
    @GetMapping
    public ResponseEntity<List<Room>> getAllRooms() {
        System.out.println("\n>>> [CONSOLE LOG] Incoming GET request to fetch all rooms...");
        
        List<Room> rooms = roomService.getAllRooms();
        
        System.out.println(">>> [CONSOLE LOG] SUCCESS: Retrieved " + rooms.size() + " total room records from database.");
        for (Room r : rooms) {
            System.out.println("  - ID: " + r.getId() + " | Room #: " + r.getRoomNumber() + " | Type: " + r.getType() + " | Available: " + r.isAvailable());
        }
        return new ResponseEntity<>(rooms, HttpStatus.OK);
    }

    // Get all rooms that are currently available
    @GetMapping("/available")
    public ResponseEntity<List<Room>> getAvailableRooms() {
        System.out.println("\n>>> [CONSOLE LOG] Incoming GET request to fetch available rooms...");

        List<Room> rooms = roomService.getAvailableRooms();

        System.out.println(">>> [CONSOLE LOG] SUCCESS: Found " + rooms.size() + " available rooms.");
        return new ResponseEntity<>(rooms, HttpStatus.OK);
    }

    // Get a single Room by ID
    @GetMapping("/{id}")
    public ResponseEntity<Room> getRoomById(@PathVariable String id) {
        System.out.println("\n>>> [CONSOLE LOG] Incoming GET request to fetch Room by ID: " + id);
        
        Optional<Room> room = roomService.getRoomById(id);
        
        if (room.isPresent()) {
            System.out.println(">>> [CONSOLE LOG] SUCCESS: Found Room #" + room.get().getRoomNumber());
            return new ResponseEntity<>(room.get(), HttpStatus.OK);
        } else {
            System.out.println(">>> [CONSOLE LOG] WARNING: Room ID " + id + " was not found in the system.");
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    // Update Room details by ID
    @PutMapping("/{id}")
    public ResponseEntity<Room> updateRoom(@PathVariable String id, @RequestBody Room roomDetails) {
        System.out.println("\n>>> [CONSOLE LOG] Incoming PUT request to update details for Room ID: " + id);
        
        Optional<Room> optionalRoom = roomService.getRoomById(id);

        if (optionalRoom.isPresent()) {
            Room existingRoom = optionalRoom.get();
            System.out.println(">>> Found old record: Room #" + existingRoom.getRoomNumber() + " (" + existingRoom.getType() + ")");
            
            existingRoom.setRoomNumber(roomDetails.getRoomNumber());
            existingRoom.setType(roomDetails.getType());
            existingRoom.setPrice(roomDetails.getPrice());
            existingRoom.setAvailable(roomDetails.isAvailable());
            existingRoom.setAmenities(roomDetails.getAmenities());
            
            Room updatedRoom = roomService.saveRoom(existingRoom);
            
            System.out.println(">>> [CONSOLE LOG] SUCCESS: Updated Room metrics to: #" + updatedRoom.getRoomNumber() + " | Price: $" + updatedRoom.getPrice() + " | Available: " + updatedRoom.isAvailable());
            return new ResponseEntity<>(updatedRoom, HttpStatus.OK);
        } else {
            System.out.println(">>> [CONSOLE LOG] ERROR: Could not update. Room ID " + id + " does not exist.");
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    // Assign one or more Amenities to a Room (completes the Many-to-Many mapping).
    // Request body: a JSON array of Amenity IDs, e.g. ["64f...", "64f..."]
    @PostMapping("/{id}/amenities")
    public ResponseEntity<Room> assignAmenitiesToRoom(@PathVariable String id, @RequestBody List<String> amenityIds) {
        System.out.println("\n>>> [CONSOLE LOG] POST request: Assigning " + amenityIds.size() + " amenities to Room ID: " + id);

        Optional<Room> optionalRoom = roomService.getRoomById(id);
        if (optionalRoom.isEmpty()) {
            System.out.println(">>> [CONSOLE LOG] ERROR: Room ID " + id + " was not found.");
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }

        Room room = optionalRoom.get();
        List<Amenity> resolvedAmenities = new ArrayList<>();
        for (String amenityId : amenityIds) {
            amenityService.getAmenityById(amenityId).ifPresent(resolvedAmenities::add);
        }

        room.setAmenities(resolvedAmenities);
        Room updatedRoom = roomService.saveRoom(room);

        System.out.println(">>> [CONSOLE LOG] SUCCESS: Room #" + updatedRoom.getRoomNumber() + " now has " + resolvedAmenities.size() + " amenities.");
        return new ResponseEntity<>(updatedRoom, HttpStatus.OK);
    }

    // Delete a Room by ID
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteRoom(@PathVariable String id) {
        System.out.println("\n>>> [CONSOLE LOG] Incoming DELETE request for Room ID: " + id);
        
        Optional<Room> room = roomService.getRoomById(id);
        if (room.isPresent()) {
            System.out.println(">>> Confirmed existence of Room #" + room.get().getRoomNumber() + ". Proceeding with drop extraction...");
            roomService.deleteRoom(id);
            System.out.println(">>> [CONSOLE LOG] SUCCESS: Room ID " + id + " has been permanently wiped from the cluster.");
            return new ResponseEntity<>(HttpStatus.NO_CONTENT);
        } else {
            System.out.println(">>> [CONSOLE LOG] ERROR: Deletion failed. Target Room ID " + id + " was not found.");
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }
}