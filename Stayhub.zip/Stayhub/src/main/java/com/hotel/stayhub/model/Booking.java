package com.hotel.stayhub.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.DBRef;
import java.time.LocalDate;

@Document(collection = "bookings")
public class Booking {

    @Id
    private String id;
    
    private LocalDate checkInDate;
    private LocalDate checkOutDate;
    private double totalAmount;
    private String status; // e.g. CONFIRMED, CHECKED_IN, CHECKED_OUT, CANCELLED

    // Many-to-One relationship mapping: Multiple bookings point to one Guest
    @DBRef
    private Guest guest;

    // Many-to-One relationship mapping: Multiple bookings point to one Room
    @DBRef
    private Room room;

    // One-to-One relationship mapping: Each booking has exactly one payment record
    // We use Embedding here to store the Payment details directly inside the Booking document
    private Payment payment;

    // Default Constructor (Required by MongoDB)
    public Booking() {
    }

    // Parameterized Constructor
    public Booking(LocalDate checkInDate, LocalDate checkOutDate, double totalAmount, Guest guest, Room room, Payment payment) {
        this.checkInDate = checkInDate;
        this.checkOutDate = checkOutDate;
        this.totalAmount = totalAmount;
        this.guest = guest;
        this.room = room;
        this.payment = payment;
    }

    // Getters and Setters
    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public LocalDate getCheckInDate() {
        return checkInDate;
    }

    public void setCheckInDate(LocalDate checkInDate) {
        this.checkInDate = checkInDate;
    }

    public LocalDate getCheckOutDate() {
        return checkOutDate;
    }

    public void setCheckOutDate(LocalDate checkOutDate) {
        this.checkOutDate = checkOutDate;
    }

    public double getTotalAmount() {
        return totalAmount;
    }

    public void setTotalAmount(double totalAmount) {
        this.totalAmount = totalAmount;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public Guest getGuest() {
        return guest;
    }

    public void setGuest(Guest guest) {
        this.guest = guest;
    }

    public Room getRoom() {
        return room;
    }

    public void setRoom(Room room) {
        this.room = room;
    }

    public Payment getPayment() {
        return payment;
    }

    public void setPayment(Payment payment) {
        this.payment = payment;
    }
}