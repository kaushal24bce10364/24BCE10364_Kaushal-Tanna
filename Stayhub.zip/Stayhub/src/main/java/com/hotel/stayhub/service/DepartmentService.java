package com.hotel.stayhub.service;

import com.hotel.stayhub.model.Department;
import com.hotel.stayhub.repository.DepartmentRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class DepartmentService {

    @Autowired
    private DepartmentRepository departmentRepository;

    // Create or Update a Department
    public Department saveDepartment(Department department) {
        return departmentRepository.save(department);
    }

    // Get all Departments
    public List<Department> getAllDepartments() {
        return departmentRepository.findAll();
    }

    // Get a single Department by ID
    public Optional<Department> getDepartmentById(String id) {
        return departmentRepository.findById(id);
    }

    // Delete a Department by ID
    public void deleteDepartment(String id) {
        departmentRepository.deleteById(id);
    }
}