package com.hotel.stayhub.service;

import com.hotel.stayhub.model.Payment;
import com.hotel.stayhub.repository.PaymentRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class PaymentService {

    @Autowired
    private PaymentRepository paymentRepository;

    // Create or Update a Payment
    public Payment savePayment(Payment payment) {
        return paymentRepository.save(payment);
    }

    // Get all Payments
    public List<Payment> getAllPayments() {
        return paymentRepository.findAll();
    }

    // Get a single Payment by ID
    public Optional<Payment> getPaymentById(String id) {
        return paymentRepository.findById(id);
    }

    // Get the Payment record linked to a specific Booking
    public Optional<Payment> getPaymentByBookingId(String bookingId) {
        return paymentRepository.findByBookingId(bookingId);
    }

    // Delete a Payment by ID
    public void deletePayment(String id) {
        paymentRepository.deleteById(id);
    }
}