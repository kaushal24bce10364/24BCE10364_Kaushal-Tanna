package com.hotel.stayhub.repository;

import com.hotel.stayhub.model.Staff;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface StaffRepository extends MongoRepository<Staff, String> {
    // This interface automatically inherits full CRUD operations for the staff collection

    // Custom query to support One-to-Many lookup: all staff belonging to a given department
    java.util.List<Staff> findByDepartment_Id(String departmentId);
}