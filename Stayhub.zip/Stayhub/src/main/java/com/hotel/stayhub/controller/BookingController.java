package com.hotel.stayhub.controller;

import com.hotel.stayhub.model.Booking;
import com.hotel.stayhub.model.Payment;
import com.hotel.stayhub.service.BookingService;
import com.hotel.stayhub.service.PaymentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/bookings")
public class BookingController {

    @Autowired
    private BookingService bookingService;

    @Autowired
    private PaymentService paymentService;

    // Create a new Booking
    @PostMapping
    public ResponseEntity<Booking> createBooking(@RequestBody Booking booking) {
        Booking savedBooking = bookingService.saveBooking(booking);
        syncPaymentWithBooking(savedBooking);
        return new ResponseEntity<>(savedBooking, HttpStatus.CREATED);
    }

    // Get all Bookings
    @GetMapping
    public ResponseEntity<List<Booking>> getAllBookings() {
        List<Booking> bookings = bookingService.getAllBookings();
        return new ResponseEntity<>(bookings, HttpStatus.OK);
    }

    // Get a single Booking by ID
    @GetMapping("/{id}")
    public ResponseEntity<Booking> getBookingById(@PathVariable String id) {
        Optional<Booking> booking = bookingService.getBookingById(id);
        return booking.map(value -> new ResponseEntity<>(value, HttpStatus.OK))
                .orElseGet(() -> new ResponseEntity<>(HttpStatus.NOT_FOUND));
    }

    // Get all Bookings made by a specific Guest (One-to-Many lookup)
    @GetMapping("/guest/{guestId}")
    public ResponseEntity<List<Booking>> getBookingsByGuestId(@PathVariable String guestId) {
        List<Booking> bookings = bookingService.getBookingsByGuestId(guestId);
        return new ResponseEntity<>(bookings, HttpStatus.OK);
    }

    // Update a Booking by ID
    @PutMapping("/{id}")
    public ResponseEntity<Booking> updateBooking(@PathVariable String id, @RequestBody Booking bookingDetails) {
        Optional<Booking> optionalBooking = bookingService.getBookingById(id);

        if (optionalBooking.isPresent()) {
            Booking existingBooking = optionalBooking.get();
            existingBooking.setGuest(bookingDetails.getGuest());
            existingBooking.setRoom(bookingDetails.getRoom());
            existingBooking.setCheckInDate(bookingDetails.getCheckInDate());
            existingBooking.setCheckOutDate(bookingDetails.getCheckOutDate());
            existingBooking.setTotalAmount(bookingDetails.getTotalAmount());
            existingBooking.setStatus(bookingDetails.getStatus());
            existingBooking.setPayment(bookingDetails.getPayment());
            
            Booking updatedBooking = bookingService.saveBooking(existingBooking);
            syncPaymentWithBooking(updatedBooking);
            return new ResponseEntity<>(updatedBooking, HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    // Delete a Booking by ID
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteBooking(@PathVariable String id) {
        Optional<Booking> booking = bookingService.getBookingById(id);
        if (booking.isPresent()) {
            bookingService.deleteBooking(id);
            return new ResponseEntity<>(HttpStatus.NO_CONTENT);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    // Keeps the standalone "payments" collection in sync with the Payment object
    // embedded inside this Booking, so GET /api/payments/booking/{bookingId} always
    // reflects the same data shown inside the Booking document itself.
    private void syncPaymentWithBooking(Booking booking) {
        Payment embedded = booking.getPayment();
        if (embedded == null) {
            return;
        }
        Optional<Payment> existing = paymentService.getPaymentByBookingId(booking.getId());
        Payment toSave = existing.orElse(new Payment());
        toSave.setBookingId(booking.getId());
        toSave.setAmount(embedded.getAmount());
        toSave.setPaymentMethod(embedded.getPaymentMethod());
        toSave.setStatus(embedded.getStatus());
        toSave.setTransactionDate(embedded.getTransactionDate());
        paymentService.savePayment(toSave);
    }
}