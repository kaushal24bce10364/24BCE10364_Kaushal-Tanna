package com.hotel.stayhub.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.DBRef;

@Document(collection = "staff")
public class Staff {

    @Id
    private String id;
    private String name;
    private String role;
    private String phoneNumber;

    // Many-to-One relationship: Many staff members belong to one department
    @DBRef
    private Department department;

    // Default Constructor (Required by MongoDB)
    public Staff() {
    }

    // Parameterized Constructor
    public Staff(String name, String role, String phoneNumber, Department department) {
        this.name = name;
        this.role = role;
        this.phoneNumber = phoneNumber;
        this.department = department;
    }

    // Getters and Setters
    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getRole() {
        return role;
    }

    public void setRole(String role) {
        this.role = role;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public Department getDepartment() {
        return department;
    }

    public void setDepartment(Department department) {
        this.department = department;
    }
}