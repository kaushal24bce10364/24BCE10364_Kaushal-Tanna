package com.hotel.stayhub.service;

import com.hotel.stayhub.model.Room;
import com.hotel.stayhub.repository.RoomRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class RoomService {

    @Autowired
    private RoomRepository roomRepository;

    // Create or Update Room
    public Room saveRoom(Room room) {
        return roomRepository.save(room);
    }

    // Get all Rooms
    public List<Room> getAllRooms() {
        return roomRepository.findAll();
    }

    // Get a single Room by ID
    public Optional<Room> getRoomById(String id) {
        return roomRepository.findById(id);
    }

    // Get only the rooms that are currently available
    public List<Room> getAvailableRooms() {
        return roomRepository.findByAvailableTrue();
    }

    // Delete a Room by ID
    public void deleteRoom(String id) {
        roomRepository.deleteById(id);
    }
}