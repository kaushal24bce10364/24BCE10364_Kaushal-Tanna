package com.hotel.stayhub.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "departments")
public class Department {

    @Id
    private String id;
    private String departmentName; // Aligned with Controller
    private double budget;         // Aligned with Controller

    // Default Constructor
    public Department() {
    }

    // Parameterized Constructor
    public Department(String departmentName, double budget) {
        this.departmentName = departmentName;
        this.budget = budget;
    }

    // Getters and Setters
    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getDepartmentName() {
        return departmentName;
    }

    public void setDepartmentName(String departmentName) {
        this.departmentName = departmentName;
    }

    public double getBudget() {
        return budget;
    }

    public void setBudget(double budget) {
        this.budget = budget;
    }
}