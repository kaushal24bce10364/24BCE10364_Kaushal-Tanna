package com.hotel.stayhub.repository;

import com.hotel.stayhub.model.Booking;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface BookingRepository extends MongoRepository<Booking, String> {
    // This interface automatically inherits full CRUD operations for the bookings collection

    // Custom query to support One-to-Many lookup: all bookings made by a given guest.
    // "Guest_Id" tells Spring Data to traverse the @DBRef'd Guest object and match on its id.
    java.util.List<Booking> findByGuest_Id(String guestId);
}