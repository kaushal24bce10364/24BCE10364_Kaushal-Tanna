package com.hotel.stayhub.controller;

import com.hotel.stayhub.model.Guest;
import com.hotel.stayhub.service.GuestService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/guests")
public class GuestController {

    @Autowired
    private GuestService guestService;

    // Create a new Guest entry
    @PostMapping
    public ResponseEntity<Guest> createGuest(@RequestBody Guest guest) {
        System.out.println("\n>>> [CONSOLE LOG] POST request: Registering a new guest...");
        System.out.println(">>> Attempting to save: " + guest.getFirstName() + " " + guest.getLastName() + " (" + guest.getEmail() + ")");
        
        Guest savedGuest = guestService.saveGuest(guest);
        
        System.out.println(">>> [CONSOLE LOG] SUCCESS: Guest saved with MongoDB ID: " + savedGuest.getId());
        return new ResponseEntity<>(savedGuest, HttpStatus.CREATED);
    }

    // Get all Guests
    @GetMapping
    public ResponseEntity<List<Guest>> getAllGuests() {
        System.out.println("\n>>> [CONSOLE LOG] GET request: Fetching all guest files...");
        
        List<Guest> guests = guestService.getAllGuests();
        
        System.out.println(">>> [CONSOLE LOG] SUCCESS: Retrieved " + guests.size() + " guest records from cluster.");
        for (Guest g : guests) {
            System.out.println("  - ID: " + g.getId() + " | Name: " + g.getFirstName() + " " + g.getLastName() + " | Phone: " + g.getPhone());
        }
        return new ResponseEntity<>(guests, HttpStatus.OK);
    }

    // Get a single Guest by ID
    @GetMapping("/{id}")
    public ResponseEntity<Guest> getGuestById(@PathVariable String id) {
        System.out.println("\n>>> [CONSOLE LOG] GET request: Looking up Guest ID: " + id);
        
        Optional<Guest> guest = guestService.getGuestById(id);
        
        if (guest.isPresent()) {
            System.out.println(">>> [CONSOLE LOG] SUCCESS: Found matching profile: " + guest.get().getFirstName() + " " + guest.get().getLastName());
            return new ResponseEntity<>(guest.get(), HttpStatus.OK);
        } else {
            System.out.println(">>> [CONSOLE LOG] WARNING: Guest ID " + id + " does not exist in the system.");
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    // Update Guest details by ID
    @PutMapping("/{id}")
    public ResponseEntity<Guest> updateGuest(@PathVariable String id, @RequestBody Guest guestDetails) {
        System.out.println("\n>>> [CONSOLE LOG] PUT request: Modifying profile for Guest ID: " + id);
        
        Optional<Guest> optionalGuest = guestService.getGuestById(id);

        if (optionalGuest.isPresent()) {
            Guest existingGuest = optionalGuest.get();
            System.out.println(">>> Found current data: " + existingGuest.getFirstName() + " " + existingGuest.getLastName());
            
            existingGuest.setFirstName(guestDetails.getFirstName());
            existingGuest.setLastName(guestDetails.getLastName());
            existingGuest.setEmail(guestDetails.getEmail());
            existingGuest.setPhone(guestDetails.getPhone());
            
            Guest updatedGuest = guestService.saveGuest(existingGuest);
            
            System.out.println(">>> [CONSOLE LOG] SUCCESS: Guest updated to: " + updatedGuest.getFirstName() + " " + updatedGuest.getLastName());
            return new ResponseEntity<>(updatedGuest, HttpStatus.OK);
        } else {
            System.out.println(">>> [CONSOLE LOG] ERROR: Update failed. Target Guest ID " + id + " missing.");
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    // Delete a Guest by ID
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteGuest(@PathVariable String id) {
        System.out.println("\n>>> [CONSOLE LOG] DELETE request: Erasing Guest ID: " + id);
        
        Optional<Guest> guest = guestService.getGuestById(id);
        if (guest.isPresent()) {
            System.out.println(">>> Profile confirmed for " + guest.get().getFirstName() + ". Executing deletion drop...");
            guestService.deleteGuest(id);
            System.out.println(">>> [CONSOLE LOG] SUCCESS: Guest ID " + id + " has been completely removed.");
            return new ResponseEntity<>(HttpStatus.NO_CONTENT);
        } else {
            System.out.println(">>> [CONSOLE LOG] ERROR: Drop aborted. Guest ID " + id + " was not found.");
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }
}