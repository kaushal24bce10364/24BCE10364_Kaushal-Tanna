package com.hotel.stayhub.service;

import com.hotel.stayhub.model.Guest;
import com.hotel.stayhub.repository.GuestRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class GuestService {

    @Autowired
    private GuestRepository guestRepository;

    // Create or Update a Guest
    public Guest saveGuest(Guest guest) {
        return guestRepository.save(guest);
    }

    // Get all Guests
    public List<Guest> getAllGuests() {
        return guestRepository.findAll();
    }

    // Get a single Guest by ID
    public Optional<Guest> getGuestById(String id) {
        return guestRepository.findById(id);
    }

    // Delete a Guest by ID
    public void deleteGuest(String id) {
        guestRepository.deleteById(id);
    }
}