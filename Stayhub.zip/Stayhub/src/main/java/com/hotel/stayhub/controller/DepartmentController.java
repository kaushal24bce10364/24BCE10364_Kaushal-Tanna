package com.hotel.stayhub.controller;

import com.hotel.stayhub.model.Department;
import com.hotel.stayhub.model.Staff;
import com.hotel.stayhub.service.DepartmentService;
import com.hotel.stayhub.service.StaffService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/departments")
public class DepartmentController {

    @Autowired
    private DepartmentService departmentService;

    @Autowired
    private StaffService staffService;

    // Create a new Department entry
    @PostMapping
    public ResponseEntity<Department> createDepartment(@RequestBody Department department) {
        System.out.println("\n>>> [CONSOLE LOG] POST request: Creating new hotel department...");
        System.out.println(">>> Attempting to setup division: " + department.getDepartmentName());
        
        Department savedDepartment = departmentService.saveDepartment(department);
        
        System.out.println(">>> [CONSOLE LOG] SUCCESS: Department saved with MongoDB ID: " + savedDepartment.getId());
        return new ResponseEntity<>(savedDepartment, HttpStatus.CREATED);
    }

    // Get all Departments
    @GetMapping
    public ResponseEntity<List<Department>> getAllDepartments() {
        System.out.println("\n>>> [CONSOLE LOG] GET request: Fetching all active hotel departments...");
        
        List<Department> departments = departmentService.getAllDepartments();
        
        System.out.println(">>> [CONSOLE LOG] SUCCESS: Found " + departments.size() + " operational divisions.");
        for (Department d : departments) {
            System.out.println("  - ID: " + d.getId() + " | Department Name: " + d.getDepartmentName() + " | Budget: $" + d.getBudget());
        }
        return new ResponseEntity<>(departments, HttpStatus.OK);
    }

    // Get a single Department by ID
    @GetMapping("/{id}")
    public ResponseEntity<Department> getDepartmentById(@PathVariable String id) {
        System.out.println("\n>>> [CONSOLE LOG] GET request: Locating Department by ID: " + id);
        
        Optional<Department> department = departmentService.getDepartmentById(id);
        
        if (department.isPresent()) {
            System.out.println(">>> [CONSOLE LOG] SUCCESS: Found division: " + department.get().getDepartmentName());
            return new ResponseEntity<>(department.get(), HttpStatus.OK);
        } else {
            System.out.println(">>> [CONSOLE LOG] WARNING: Department ID " + id + " could not be resolved.");
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    // Get all Staff members belonging to a specific Department (One-to-Many lookup)
    @GetMapping("/{id}/staff")
    public ResponseEntity<List<Staff>> getStaffInDepartment(@PathVariable String id) {
        System.out.println("\n>>> [CONSOLE LOG] GET request: Fetching staff for Department ID: " + id);

        List<Staff> staffList = staffService.getStaffByDepartmentId(id);

        System.out.println(">>> [CONSOLE LOG] SUCCESS: Found " + staffList.size() + " staff members in department " + id);
        return new ResponseEntity<>(staffList, HttpStatus.OK);
    }

    // Update Department details by ID
    @PutMapping("/{id}")
    public ResponseEntity<Department> updateDepartment(@PathVariable String id, @RequestBody Department departmentDetails) {
        System.out.println("\n>>> [CONSOLE LOG] PUT request: Restructuring settings for Department ID: " + id);
        
        Optional<Department> optionalDepartment = departmentService.getDepartmentById(id);

        if (optionalDepartment.isPresent()) {
            Department existingDepartment = optionalDepartment.get();
            System.out.println(">>> Modifying old record layout for: " + existingDepartment.getDepartmentName());
            
            existingDepartment.setDepartmentName(departmentDetails.getDepartmentName());
            existingDepartment.setBudget(departmentDetails.getBudget());
            
            Department updatedDepartment = departmentService.saveDepartment(existingDepartment);
            
            System.out.println(">>> [CONSOLE LOG] SUCCESS: Division modified to: " + updatedDepartment.getDepartmentName() + " | New Budget: $" + updatedDepartment.getBudget());
            return new ResponseEntity<>(updatedDepartment, HttpStatus.OK);
        } else {
            System.out.println(">>> [CONSOLE LOG] ERROR: Refactor canceled. Department ID " + id + " does not exist.");
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    // Delete a Department by ID
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteDepartment(@PathVariable String id) {
        System.out.println("\n>>> [CONSOLE LOG] DELETE request: Dismantling Department ID: " + id);
        
        Optional<Department> department = departmentService.getDepartmentById(id);
        if (department.isPresent()) {
            System.out.println(">>> Verified division targeting: " + department.get().getDepartmentName() + ". Discharging node...");
            departmentService.deleteDepartment(id);
            System.out.println(">>> [CONSOLE LOG] SUCCESS: Department ID " + id + " has been scrubbed out.");
            return new ResponseEntity<>(HttpStatus.NO_CONTENT);
        } else {
            System.out.println(">>> [CONSOLE LOG] ERROR: Destruction failed. Target Department ID " + id + " not found.");
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }
}