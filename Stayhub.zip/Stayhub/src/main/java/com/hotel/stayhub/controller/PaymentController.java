package com.hotel.stayhub.controller;

import com.hotel.stayhub.model.Payment;
import com.hotel.stayhub.service.PaymentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/payments")
public class PaymentController {

    @Autowired
    private PaymentService paymentService;

    // Create a new Payment entry
    @PostMapping
    public ResponseEntity<Payment> createPayment(@RequestBody Payment payment) {
        System.out.println("\n>>> [CONSOLE LOG] POST request: Processing new payment...");
        System.out.println(">>> Details: Amount: $" + payment.getAmount() + " | Method: " + payment.getPaymentMethod());
        
        Payment savedPayment = paymentService.savePayment(payment);
        
        System.out.println(">>> [CONSOLE LOG] SUCCESS: Payment recorded with ID: " + savedPayment.getId());
        return new ResponseEntity<>(savedPayment, HttpStatus.CREATED);
    }

    // Get all Payments
    @GetMapping
    public ResponseEntity<List<Payment>> getAllPayments() {
        System.out.println("\n>>> [CONSOLE LOG] GET request: Fetching all payment records...");
        
        List<Payment> payments = paymentService.getAllPayments();
        
        System.out.println(">>> [CONSOLE LOG] SUCCESS: Total " + payments.size() + " payments retrieved.");
        return new ResponseEntity<>(payments, HttpStatus.OK);
    }

    // Get a single Payment by ID
    @GetMapping("/{id}")
    public ResponseEntity<Payment> getPaymentById(@PathVariable String id) {
        System.out.println("\n>>> [CONSOLE LOG] GET request: Searching for Payment ID: " + id);
        
        Optional<Payment> payment = paymentService.getPaymentById(id);
        
        if (payment.isPresent()) {
            System.out.println(">>> [CONSOLE LOG] SUCCESS: Found payment record for amount: $" + payment.get().getAmount());
            return new ResponseEntity<>(payment.get(), HttpStatus.OK);
        } else {
            System.out.println(">>> [CONSOLE LOG] WARNING: Payment ID " + id + " not found.");
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    // Get the Payment record linked to a specific Booking (One-to-One lookup)
    @GetMapping("/booking/{bookingId}")
    public ResponseEntity<Payment> getPaymentByBookingId(@PathVariable String bookingId) {
        System.out.println("\n>>> [CONSOLE LOG] GET request: Searching for Payment linked to Booking ID: " + bookingId);

        Optional<Payment> payment = paymentService.getPaymentByBookingId(bookingId);

        if (payment.isPresent()) {
            System.out.println(">>> [CONSOLE LOG] SUCCESS: Found payment for booking: " + bookingId);
            return new ResponseEntity<>(payment.get(), HttpStatus.OK);
        } else {
            System.out.println(">>> [CONSOLE LOG] WARNING: No payment found for Booking ID " + bookingId);
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    // Update Payment details by ID
    @PutMapping("/{id}")
    public ResponseEntity<Payment> updatePayment(@PathVariable String id, @RequestBody Payment paymentDetails) {
        System.out.println("\n>>> [CONSOLE LOG] PUT request: Updating Payment ID: " + id);
        
        Optional<Payment> optionalPayment = paymentService.getPaymentById(id);

        if (optionalPayment.isPresent()) {
            Payment existingPayment = optionalPayment.get();
            System.out.println(">>> Updating record: Previous Status: " + existingPayment.getStatus());
            
            existingPayment.setAmount(paymentDetails.getAmount());
            existingPayment.setPaymentMethod(paymentDetails.getPaymentMethod());
            existingPayment.setStatus(paymentDetails.getStatus());
            existingPayment.setTransactionDate(paymentDetails.getTransactionDate());
            if (paymentDetails.getBookingId() != null) {
                existingPayment.setBookingId(paymentDetails.getBookingId());
            }
            
            Payment updatedPayment = paymentService.savePayment(existingPayment);
            
            System.out.println(">>> [CONSOLE LOG] SUCCESS: Payment ID " + id + " updated to Status: " + updatedPayment.getStatus());
            return new ResponseEntity<>(updatedPayment, HttpStatus.OK);
        } else {
            System.out.println(">>> [CONSOLE LOG] ERROR: Update failed. Payment ID " + id + " not found.");
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    // Delete a Payment by ID
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deletePayment(@PathVariable String id) {
        System.out.println("\n>>> [CONSOLE LOG] DELETE request: Removing Payment ID: " + id);
        
        Optional<Payment> payment = paymentService.getPaymentById(id);
        if (payment.isPresent()) {
            paymentService.deletePayment(id);
            System.out.println(">>> [CONSOLE LOG] SUCCESS: Payment ID " + id + " successfully deleted from database.");
            return new ResponseEntity<>(HttpStatus.NO_CONTENT);
        } else {
            System.out.println(">>> [CONSOLE LOG] ERROR: Delete failed. Payment ID " + id + " does not exist.");
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }
}