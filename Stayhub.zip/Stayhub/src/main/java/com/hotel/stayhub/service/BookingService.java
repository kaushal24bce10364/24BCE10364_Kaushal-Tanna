package com.hotel.stayhub.service;

import com.hotel.stayhub.model.Booking;
import com.hotel.stayhub.repository.BookingRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class BookingService {

    @Autowired
    private BookingRepository bookingRepository;

    // Create or Update a Booking
    public Booking saveBooking(Booking booking) {
        return bookingRepository.save(booking);
    }

    // Get all Bookings
    public List<Booking> getAllBookings() {
        return bookingRepository.findAll();
    }

    // Get a single Booking by ID
    public Optional<Booking> getBookingById(String id) {
        return bookingRepository.findById(id);
    }

    // Get all Bookings made by a specific Guest (One-to-Many lookup)
    public List<Booking> getBookingsByGuestId(String guestId) {
        return bookingRepository.findByGuest_Id(guestId);
    }

    // Delete a Booking by ID
    public void deleteBooking(String id) {
        bookingRepository.deleteById(id);
    }
}