package com.hotel.stayhub.repository;

import com.hotel.stayhub.model.Room;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface RoomRepository extends MongoRepository<Room, String> {
    // This interface automatically inherits full CRUD operations for the rooms collection

    // Custom query to fetch only rooms that are currently available
    java.util.List<Room> findByAvailableTrue();
}