package com.hotel.stayhub;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class StayHubApplication {

    public static void main(String[] args) {
        // Launches the embedded Tomcat server and starts the StayHub engine
        SpringApplication.run(StayHubApplication.class, args);
    }
}