package com.hotel.stayhub;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StayHubApplicationTests {

    @Test
    void contextLoads() {
        // This test verifies that the Spring Boot application context
        // loads successfully — meaning all beans (Controllers, Services,
        // Repositories) are wired correctly and the MongoDB connection
        // configuration is valid.
    }

}