# 🏨 StayHub — Integrated Hotel Management Platform

> A backend REST API platform for managing hotel operations — guests, rooms, bookings, payments, staff, and departments — built with Java Spring Boot and MongoDB Atlas.

---

## 📌 Overview

**StayHub** is a pure backend hotel management system. There's no frontend — every operation is performed through REST APIs and tested via **Postman** and **Swagger UI**. The project demonstrates full CRUD operations across 7 entities and implements all four MongoDB relationship mapping types (One-to-One, One-to-Many, Many-to-One, Many-to-Many).

| | |
|---|---|
| **Author** | Kaushal Tanna |
| **Registration No.** | 24BCE10364 |
| **Type** | Academic Backend Project |
| **Frontend** | None (API-only, console-based) |

---

## ⚙️ Tech Stack

| Layer | Technology | Version |
|---|---|---|
| Language | Java | 21 |
| Framework | Spring Boot | 3.4.3 |
| Database | MongoDB Atlas | Cloud (M0 Free Tier) |
| ODM | Spring Data MongoDB | Bundled with Spring Boot 3.4.3 |
| API Docs | Springdoc OpenAPI (Swagger UI) | 2.8.5 |
| Validation | Spring Boot Starter Validation | Bundled |
| Testing | Spring Boot Starter Test (JUnit 5) | Bundled |
| Build Tool | Maven | 4.0.0 (pom model) |
| IDE | Eclipse + Spring Tools Suite | — |
| API Testing | Postman | — |

---

## 🧩 Core Entities

StayHub manages **7 entities**, each with full CRUD support:

- 🧑 **Guest** — personal and contact details
- 🛏️ **Room** — type, price, and availability status
- 📅 **Booking** — links a guest to a room with check-in/check-out dates
- 💳 **Payment** — payment details for a booking
- 👨‍💼 **Staff** — hotel employee records
- 🏢 **Department** — groups staff (e.g. Housekeeping, Reception, Food & Beverage)
- 🛎️ **Amenity** — facilities like Pool, WiFi, Gym, Spa

---

## 🔗 MongoDB Relationship Mappings

All four relationship types are implemented:

| Type | Relationship | Description |
|---|---|---|
| **One-to-One** | Booking ↔ Payment | Each booking has exactly one payment record |
| **One-to-Many** | Guest → Bookings | A guest can have multiple bookings |
| **One-to-Many** | Department → Staff | A department contains multiple staff members |
| **Many-to-One** | Bookings → Guest | Multiple bookings belong to one guest |
| **Many-to-One** | Staff → Department | Multiple staff belong to one department |
| **Many-to-Many** | Room ↔ Amenities | A room has many amenities; an amenity applies to many rooms |

---

## 🏗️ Architecture

StayHub follows a clean **3-layer architecture**:

```
Controller  →  Service  →  Repository  →  MongoDB Atlas
```

- **Controller** — handles HTTP requests/responses, exposes REST endpoints
- **Service** — contains business logic and validation
- **Repository** — interfaces with MongoDB via Spring Data
- **Model** — defines document schemas with MongoDB annotations

---

## 📁 Project Structure

```
stayhub/
├── src/
│   ├── main/
│   │   ├── java/com/hotel/stayhub/
│   │   │   ├── controller/        → REST endpoints (Guest, Room, Booking, Payment, Staff, Department, Amenity)
│   │   │   ├── model/             → Entity classes with MongoDB annotations
│   │   │   ├── repository/        → Spring Data MongoDB repositories
│   │   │   ├── service/           → Business logic layer
│   │   │   ├── config/            → OpenAPI / Swagger configuration
│   │   │   └── StayHubApplication.java
│   │   └── resources/
│   │       └── application.properties
│   └── test/
│       └── java/com/hotel/stayhub/
│           └── StayHubApplicationTests.java
├── Screenshot/                    → Postman API test screenshots
├── README_StayHub.md
├── StayHub_User_Manual.docx
└── pom.xml
```

---

## 🚀 Getting Started

### Prerequisites

- Java 21 or above
- Eclipse IDE with Spring Tools Suite (STS) plugin
- MongoDB Atlas account (free M0 cluster) or local MongoDB
- Postman (no account required — use offline mode)

### Setup Steps

1. **Clone or extract** the project into Eclipse as an existing Maven project
2. **Configure MongoDB connection** — set your Atlas URI as an environment variable:
   ```
   MONGODB_URI=mongodb+srv://<username>:<password>@cluster0.xxxxx.mongodb.net/stayhub_db
   ```
3. **Update Maven dependencies** — right-click project → `Maven` → `Update Project`
4. **Run the application** — right-click `StayHubApplication.java` → `Run As` → `Java Application`
5. **Confirm startup** — console should display `Started StayHubApplication` and the app runs on port `8080`

---

## 📡 API Documentation

Once running, access Swagger UI at:

```
http://localhost:8080/swagger-ui.html
```

Or test manually via Postman using the endpoints below.

### Guest APIs
| Method | Endpoint | Description |
|---|---|---|
| POST | `/api/guests` | Create a new guest |
| GET | `/api/guests` | Get all guests |
| GET | `/api/guests/{id}` | Get guest by ID |
| PUT | `/api/guests/{id}` | Update guest details |
| DELETE | `/api/guests/{id}` | Delete a guest |

### Room APIs
| Method | Endpoint | Description |
|---|---|---|
| POST | `/api/rooms` | Add a new room |
| GET | `/api/rooms` | Get all rooms |
| GET | `/api/rooms/available` | Get all available rooms |
| GET | `/api/rooms/{id}` | Get room by ID |
| PUT | `/api/rooms/{id}` | Update room details or status |
| POST | `/api/rooms/{id}/amenities` | Assign amenities to a room |
| DELETE | `/api/rooms/{id}` | Delete a room |

### Booking APIs
| Method | Endpoint | Description |
|---|---|---|
| POST | `/api/bookings` | Create a booking (links Guest + Room) |
| GET | `/api/bookings` | Get all bookings |
| GET | `/api/bookings/{id}` | Get booking by ID |
| GET | `/api/bookings/guest/{guestId}` | Get bookings for a specific guest |
| PUT | `/api/bookings/{id}` | Update booking details |
| DELETE | `/api/bookings/{id}` | Cancel a booking |

### Payment APIs
| Method | Endpoint | Description |
|---|---|---|
| POST | `/api/payments` | Record a payment for a booking |
| GET | `/api/payments/{id}` | Get payment by ID |
| GET | `/api/payments/booking/{bookingId}` | Get payment by booking ID |
| PUT | `/api/payments/{id}` | Update payment status |

### Staff APIs
| Method | Endpoint | Description |
|---|---|---|
| POST | `/api/staff` | Add a new staff member |
| GET | `/api/staff` | Get all staff |
| GET | `/api/staff/{id}` | Get staff by ID |
| PUT | `/api/staff/{id}` | Update staff details |
| DELETE | `/api/staff/{id}` | Remove a staff member |

### Department APIs
| Method | Endpoint | Description |
|---|---|---|
| POST | `/api/departments` | Create a new department |
| GET | `/api/departments` | Get all departments |
| GET | `/api/departments/{id}` | Get department by ID |
| GET | `/api/departments/{id}/staff` | Get all staff in a department |
| PUT | `/api/departments/{id}` | Update department details |
| DELETE | `/api/departments/{id}` | Delete a department |

### Amenity APIs
| Method | Endpoint | Description |
|---|---|---|
| POST | `/api/amenities` | Add a new amenity |
| GET | `/api/amenities` | Get all amenities |
| GET | `/api/amenities/{id}` | Get amenity by ID |
| PUT | `/api/amenities/{id}` | Update amenity details |
| DELETE | `/api/amenities/{id}` | Delete an amenity |

---

## 🔐 Authentication & Security

This is an academic backend project and does not implement token-based authentication (JWT). All APIs are open for testing purposes. Database-level security is handled via:

- MongoDB Atlas IP whitelisting
- Database username/password authentication
- Encrypted connection via `mongodb+srv://` (TLS)

> **Future enhancement:** Add Spring Security with JWT for production-grade authentication.

---

## 🧪 Testing

A basic Spring context-load test is included at:
```
src/test/java/com/hotel/stayhub/StayHubApplicationTests.java
```

This verifies the application context, all beans, and the MongoDB connection initialize correctly. Manual API testing is documented via Postman screenshots in the `Screenshot/` folder.

---

## 📚 Additional Documentation

- **User Manual** — `StayHub_User_Manual.docx` (step-by-step run guide)
- **Postman Screenshots** — `Screenshot/` folder (sample request/response pairs per module)

---

## ✅ Project Checklist

- [x] DB Connection (MongoDB Atlas)
- [x] Console-based, no frontend
- [x] Full CRUD on all 7 entities
- [x] All 4 MongoDB relationship mapping types
- [x] REST APIs tested via Postman and Swagger
- [x] Layered architecture (Controller → Service → Repository)
- [x] Environment-variable based DB credentials (no hardcoding)

---

<p align="center"><i>Built as part of academic coursework — VIT Bhopal University</i></p>
